
//Question: Calculate the difference between two numbers.

var a=15;
var b=8;

console.log(a-b);
