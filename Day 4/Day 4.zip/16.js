//Question: Calculate the total bill amount including a 10% tip for a meal costing $60.


var bill =60;
var tip =10;

var total;

total = bill*tip/100+bill;

console.log(total);