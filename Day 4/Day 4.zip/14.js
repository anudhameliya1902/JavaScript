// Question: Calculate the simple interest for $2000 at 3% interest rate for 4 years.

var p=2000;
var rate = 3;
var n=4;

var inter;

inter = p*rate*n/100;

console.log(inter);