//Question: Calculate the total bill amount including a 15% tip for a meal costing $40.//

var bill=40;

var tip=15;

var total;

total=(bill*0.15)+bill;

console.log(total);