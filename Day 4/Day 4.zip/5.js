//Question: Find the product of two numbers.


var  a=8;
var b=4;

console.log(a*b);