// Question: Find the total cost for 3 items priced $15 each.



var rate =15;
var qty =3;

console.log(rate*qty);
