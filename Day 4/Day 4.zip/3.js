var principal = 1000;
var rate = 5;
var year =2;

var interest;


interest=principal*rate*year/100;

console.log(interest);
