// Question: Find the remainder when one number is divided by another.

var a=25;
var b=7;

console.log(a%b);