
var a=50;

var b;

b=(50*8/100)+a;  

console.log(b);