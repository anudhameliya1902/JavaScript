    // Question: Calculate the total bill amount including 7% tax for a purchase of $90.

    var bill =90;

    var rate = 7;

    var total;

    total = (bill*rate/100)+bill;

    console.log(total);