//Question: Find the sum of three numbers.


var a=10;
var b=20;
var c=30;


var sum;

sum=a+b+c;

console.log(sum);
