//Question: Calculate the monthly salary of an employee paid $18 per hour for 180 hours.

var hw=18;

var work= 180;

var salary;

salary =hw*work;

console.log(salary);
