//Question: Calculate the weekly salary of an employee paid $15 per hour for 40 hours.//

var rate = 15;
var hour = 40;

var weekaly;

weekaly=rate*hour;

console.log(weekaly);