// Question: Determine the total bill amount including 12% tax for a purchase of $80.


var bill = 80;
var rate = 12;

var total;

total=bill*rate/100+bill;

console.log(total);