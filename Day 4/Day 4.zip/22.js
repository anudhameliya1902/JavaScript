//Question: Calculate the total bill amount including 18% tax and a $5 service charge for a purchase of $80.

var bill =80;

var gst =18;

var ser =5;

console.log((bill*gst/100)+(bill*ser/100)+bill);