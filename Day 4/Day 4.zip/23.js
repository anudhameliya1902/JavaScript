//Question: Find the compound interest for $3000 at 8% compounded semi-annually for 4 years.

var p=3000;
var r=8;
var t=4;
var n=2;


var total;

total = p(1+0.08/2)
