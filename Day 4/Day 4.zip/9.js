//Question: Divide one number by another.

var a=20;
var b=5;

console.log(a/b);
