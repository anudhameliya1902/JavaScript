//Question: Determine the total bill amount including 5% tax for a purchase of $120.//


var bill =120;
var rate = 5;

var total;

total = bill*rate/100+bill;

console.log(total);
