//Q1. Swap the values of two variables without using a function. Given two variables, swap their values.


var a=15;
var b=10;

console.log(a);
console.log(b);


console.log("Swap the Value");

a=a+b;
b=a-b;
a=a-b;

console.log(a);
console.log(b);