//Q2.Divide one number to another number and find the remainder 


var a=29;
var b=6;

console.log(a%b);