//Q4.Determine if a given year is a leap year. Print true or false only.


var a=2000;

console.log(a%4==0);


var a=2001;

console.log(a%41==1);