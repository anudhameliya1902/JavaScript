    

    console.log("perimeter of cricle")
    console.log("Radius is 10");

    var r=10;
    var area;

    area =2*3.14*r;

console.log(area);