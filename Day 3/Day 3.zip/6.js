console.log("Calculation of Bil amount");

console.log("Gross Total Amount 100");
console.log("Tax Rate = 10%");

var g=100;
var r=10;
var t;

t=(100*10/100)+100;

console.log(t);
