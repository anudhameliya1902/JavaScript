console.log("Area of Tringle")
console.log("Tringle Base = 25");
console.log("Tringle Height = 20");

var B=25;
var H=20;

var area;

area =1/2*B*H;  
console.log(area);