    

    console.log("Area of cricle")
    console.log("Radius is 10");

    var r=10;
    var area;

    area =3.14*r*r;

console.log(area);