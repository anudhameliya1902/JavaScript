

var salary =2000;
 var allow =500;


 console.log(salary+allow);