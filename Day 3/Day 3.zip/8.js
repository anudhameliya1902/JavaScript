

var a= 50;

var b= 40;

console.log(a);
console.log(b);

console.log("Swap the Value ");


a=a+b;
b=a-b;
a=a-b;

console.log(a);
console.log(b);