console.log("Simple Interest")
console.log("Principal Amount = 100000");
console.log("Rate Of Interest = 8%");
console.log("Number Of Year = 2");

var p=100000;
var r=8;
var n=2;

var inter;

inter=p*r*n/100;

console.log(inter);