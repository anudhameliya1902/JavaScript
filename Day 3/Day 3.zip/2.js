    console.log("Area of rectangle")
    console.log("Rectangle width = 25");
    console.log("Rectangle Lenth = 20");

    var w=25;
    var l=20;

    var area;

    area =w*l;  
console.log(area);