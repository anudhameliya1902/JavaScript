

const pi=3.14;

pi=15;

console.log(pi);