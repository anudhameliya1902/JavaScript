var x;
var y;
var z;
 x=10;
 y=20;
 z=x+y;

 console.log(x);
 console.log(y);
 console.log(z);