
var a;

a=null;

console.log(a);