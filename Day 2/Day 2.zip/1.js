

var age=25;

console.log(age);   