
var a;

a="ALICE";

a="BOB";
console.log(a);